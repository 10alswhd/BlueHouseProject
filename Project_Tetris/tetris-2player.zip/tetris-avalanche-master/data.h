/* Allegro datafile object indexes, produced by grabber v3.1 */
/* Datafile: d:\gregm\tetris\tetris.dat */
/* Date: Wed May 12 16:08:17 1999 */
/* Do not hand edit! */

#define AVALANCHE                        0        /* BMP  */
#define BACK_1PLAYER                     1        /* BMP  */
#define BACK_2PLAYER                     2        /* BMP  */
#define FONT_NORM                        3        /* FONT */
#define FONT_TINY                        4        /* FONT */
#define FONT_TINY_FIXED                  5        /* FONT */
#define PAL                              6        /* PAL  */
#define TITLE                            7        /* BMP  */

