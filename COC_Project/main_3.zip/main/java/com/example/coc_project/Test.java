package com.example.coc_project;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;


public class Test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
    }

    public void luckpage (View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://search.naver.com/search.naver?where=nexearch&query=%EC%98%A4%EB%8A%98%EC%9D%98%EC%9A%B4%EC%84%B8&sm=top_sug.pre&fbm=1&acr=1&acq=%EC%9A%B4&qdt=0&ie=utf8"));
        startActivity(browserIntent);
    }
}
