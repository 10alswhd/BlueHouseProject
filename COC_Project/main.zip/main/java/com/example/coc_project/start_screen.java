package com.example.coc_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class start_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_screen);


    }
}

