// selection sort: inplace sorting algorithm.
// the algorithm is called selection sort since it repeatedly selects the smallest element.

void SelectionSort(vector<int> &A){
    int n = A.size();
    int min;
    for(int i=0;i<n;i++){
        min = i;
        for(int j=i;j<n;j++){
            if(A[j]<A[min])
                min = j;
        }

        swap(A[min], A[i]);
    }
}
