void insertionSort(vector<int> &A){
    int n = A.size();
    int j, key;
    for(int i=1;i<n;i++){
        j = i-1;
        key = A[i]; 
        while(j>=0 and A[j] > key){
            A[j+1] = A[j];
            j--;
        }

        A[j+1] = key;
    }
}
