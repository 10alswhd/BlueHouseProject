void bubbleSort(vector<int> &A){
    int n = A.size();

    for(int pass=n-1;pass>=0;pass--){
        for(int i=0;i<pass;i++){
            if(A[i]>A[i+1])
                swap(A[i],A[i+1]);
        }
    }
}
